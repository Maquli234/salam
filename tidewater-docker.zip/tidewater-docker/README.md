# Tidewater lab (Docker edition)

> **WARNING: intentionally vulnerable.** The web container can control the host's Docker daemon,
> so compromising it means **root on the host VM**. Run this only on a dedicated, disposable VM,
> and restrict port 80 (and SSH) to your own IP in the cloud firewall / NSG.

Attack chain: LFI (bypassable filter) -> RCE by Apache log poisoning (`www-data`) ->
Docker socket access -> host root.

| Part | Where it lives |
|------|----------------|
| Website + Apache + PHP | `tidewater` container (built from `Dockerfile`) |
| User flag, `marcus` account | inside the container (`/home/marcus/user.txt`) |
| Root flag | on the **host** (`/root/root.txt`) |
| Privesc | `/var/run/docker.sock` mounted into the container; `www-data` is added to its group |

## How the privesc stays realistic

The host's `/var/run/docker.sock` is mounted into the web container (a common real-world mistake).
At start-up the entrypoint reads the socket's group id and adds `www-data` to a matching group,
so the web user can talk to the host daemon. From the shell:
`docker run --rm -v /:/mnt alpine chroot /mnt ...` starts a new container on the **host** with the host's
filesystem mounted, which gives host root. `up.sh` pre-pulls `alpine` on the host so no internet is needed.

## Requirements

- Linux VM with Docker Engine and the Compose plugin (Ubuntu: `sudo apt install docker.io docker-compose-v2`)
- Ports: 80 open only to your IP

## Run

```bash
unzip tidewater-docker.zip && cd tidewater-docker
chmod +x *.sh docker/entrypoint.sh
sudo ./up.sh        # generates flags, builds, starts; prints the flags
sudo ./verify.sh    # runs the full chain and prints PASS/FAIL per stage
sudo ./reset.sh     # fresh container between attempts
```

Browse to `http://<vm-ip>/`. Flags and the `marcus` password are in `.env` and `.author/` (keep them private).

Plain Docker without Compose:
```bash
docker build -t tidewater-web .
docker run -d --name tidewater -p 80:80 --env-file .env \
  -v /var/run/docker.sock:/var/run/docker.sock tidewater-web
```
(`.env` needs `USER_FLAG=` and `DEV_PASS=`; the root flag must be written to the host's `/root/root.txt` yourself.)

## Layout

```
Dockerfile              php:8.2-apache + docker CLI, real Apache log files, site copied in
docker-compose.yml      port 80, env file, docker.sock mount
docker/entrypoint.sh    sets marcus password/flag, grants socket group, hides secrets from Apache
docker/tidewater.conf   Apache/PHP settings (verbose errors on)
docker/deploy-notes.txt clue explaining the socket mount
web/                    the vulnerable site
up.sh verify.sh reset.sh
docs/WALKTHROUGH.md     intended solution and vulnerability table
docs/DETECTION.md       blue-team indicators
```

## Differences from the VM edition

- Reset is simple: the container is recreated, which wipes logs, shells and attacker files inside it.
  The **host** may still be modified after a successful escalation, so use a VM snapshot for a guaranteed clean state.
- Shells land **inside the container** first; `/etc/passwd` shows the container's users, not the host's.
- The root flag is on the host, and only the Docker-socket escalation reaches it.
- Only SSH on the host (if you use it) needs managing; the container exposes just port 80.

## Making it harder

- Set `php_flag display_errors Off` in `docker/tidewater.conf` and rebuild.
- Strengthen the filter in `web/index.php` so a second bypass is needed.
- Remove the `marcus` credential reuse in `web/includes/config.php` and `docker/entrypoint.sh`.
- Replace the plain socket mount with a socket proxy that allows only some API calls, then make the player find the one allowed call that still lets them mount `/`.

## Known limits

Docker is not available in the sandbox where this was written, so the image build, `up.sh`, `reset.sh`
and `verify.sh` were only syntax-checked. The PHP site logic (filter bypass and log-include RCE) was tested on PHP 8.3.
Run `sudo ./verify.sh` first and send me any stage that fails.
