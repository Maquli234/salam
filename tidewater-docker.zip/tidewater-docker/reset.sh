#!/usr/bin/env bash
# Recreate the container from scratch (wipes logs, shells, files the attacker created inside it).
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo ./reset.sh"; exit 1; }
cd "$(dirname "${BASH_SOURCE[0]}")"
[[ -f .env && -f .author/root.flag ]] || { echo "Run ./up.sh first."; exit 1; }

docker compose down
cp .author/root.flag /root/root.txt && chmod 600 /root/root.txt
docker image inspect alpine:latest >/dev/null 2>&1 || docker pull alpine:latest
docker compose up -d --force-recreate

echo
echo "Container recreated."
OTHERS=$(docker ps -a --format '{{.Names}} ({{.Image}})' | grep -v '^tidewater ' || true)
if [[ -n "$OTHERS" ]]; then
  echo "WARNING: other containers exist (possibly created by the attacker):"
  echo "$OTHERS"
fi
echo "NOTE: a successful run means the attacker had host root. Anything on the host"
echo "(users, SSH keys, cron, SUID files) may have changed. For a guaranteed clean lab, use a dedicated VM and restore its snapshot."
