#!/bin/bash
# Runs as root inside the container, prepares secrets, then starts Apache.
set -e
: "${USER_FLAG:?USER_FLAG is not set (run ./up.sh)}"
: "${DEV_PASS:?DEV_PASS is not set (run ./up.sh)}"

# Normal user: password reuse target and user flag
echo "marcus:${DEV_PASS}" | chpasswd
printf '%s\n' "$USER_FLAG" > /home/marcus/user.txt
chown marcus:marcus /home/marcus/user.txt
chmod 600 /home/marcus/user.txt
sed -i "s|__DB_PASS__|${DEV_PASS}|" /var/www/html/includes/config.php

# Give www-data access to the mounted Docker socket by matching its group id
SOCK=/var/run/docker.sock
if [ -S "$SOCK" ]; then
  SGID=$(stat -c %g "$SOCK")
  if [ "$SGID" = "0" ]; then
    echo "WARNING: docker.sock is owned by group root (gid 0); the privesc will not work." >&2
  else
    getent group "$SGID" >/dev/null || groupadd -g "$SGID" docker
    usermod -aG "$(getent group "$SGID" | cut -d: -f1)" www-data
  fi
else
  echo "WARNING: $SOCK is not mounted; the docker privesc will not work." >&2
fi

# Do not leak secrets to Apache workers (they inherit the environment)
unset USER_FLAG DEV_PASS
exec "$@"
