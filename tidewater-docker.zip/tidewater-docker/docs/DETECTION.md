# Detection notes (blue-team view)

## Stage 1: Enumeration and LFI discovery
- **Apache access.log**: many 404s from one IP (directory brute force), requests to `/robots.txt` and `/backup/old-notes.txt`.
- Requests to `/index.php?page=` containing `../`, then `....//` (encoded as `%2e%2e%2e%2e%2f%2f` in some tools).
- **error.log / page output**: PHP warnings `include(...pages/etc/passwd): Failed to open stream` repeated with changing paths.
- Sigma-style idea: `page=` parameter containing `..` or `etc/passwd`, `/proc/self`, or `var/log`.

## Stage 2: Log poisoning and RCE
- **access.log**: a request whose **User-Agent contains `<?php`**, immediately followed by requests with `page=...var/log/apache2/access.log` and a `c=` parameter.
- `c=` values showing commands (`id`, `bash -c`, `docker run`) in the query string.
- **Process events (auditd / Sysmon for Linux / EDR)**: `apache2` spawning `sh -c`, `bash`, `id`, `python3`. A web server that spawns shells is a high-fidelity alert.
- **Network**: outbound connection from `www-data` processes to an unusual port (reverse shell), for example to port 4444.
- Suggested auditd rule: `-a always,exit -F arch=b64 -S execve -F uid=33 -k www-exec`.

## Stage 3: Credential access and lateral step
- File reads of `/var/www/html/includes/config.php` by a shell running as `www-data` (auditd `-w /var/www/html/includes/config.php -p r`).
- **auth.log**: `su: (to marcus) www-data on pts/N`, and PAM session opened for `marcus`.

## Stage 4: Docker privilege escalation
- **Docker events** (`docker events`, or journald `docker.service`): `container create/start` with image `alpine`, a bind mount of `/` (`-v /:/mnt`), initiated from a process owned by `www-data`.
- **Process events**: `docker run` executed by uid 33, then `chroot` inside the container.
- **File access**: reads of `/root/root.txt` from a container process.
- Auditd: `-w /var/run/docker.sock -p rw -k docker-sock  (on the host)` and `-w /usr/bin/docker -p x -k docker-exec`.
- Hunting query idea: any `docker run` whose arguments contain `-v /:/` or `--privileged`.

## Hardening checks that would have stopped the chain
1. Allow-list the `page` parameter (stops stage 1).
2. Keep logs unreadable by the web user (stops stage 2).
3. Do not mount the Docker socket into the web container (stops stage 4).
4. Alert on `apache2` creating shell processes (detects stage 2 early).
