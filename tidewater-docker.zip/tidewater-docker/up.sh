#!/usr/bin/env bash
# Build and start the lab. Run as root (it writes the host root flag).
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo ./up.sh"; exit 1; }
command -v docker >/dev/null || { echo "Docker is not installed."; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose plugin missing (apt install docker-compose-v2 or docker-compose-plugin)."; exit 1; }

cd "$(dirname "${BASH_SOURCE[0]}")"
mkdir -p .author; chmod 700 .author

if [[ ! -f .env ]]; then
  USER_FLAG="flag{user_$(openssl rand -hex 8)}"
  ROOT_FLAG="flag{root_$(openssl rand -hex 8)}"
  DEV_PASS="Quay-$(openssl rand -hex 5)!"
  printf "USER_FLAG=%s\nDEV_PASS=%s\n" "$USER_FLAG" "$DEV_PASS" > .env
  chmod 600 .env
  printf '%s\n' "$ROOT_FLAG" > .author/root.flag
  chmod 600 .author/root.flag
fi

# Root flag lives on the HOST: the goal of the escalation is host root
install -m 600 /dev/null /root/root.txt
cp .author/root.flag /root/root.txt
chmod 600 /root/root.txt

# The escalation runs a container on the host daemon; make sure the image is present offline
docker pull alpine:latest

docker compose up -d --build

echo
echo "=== Lab running on port 80 ==="
echo "User flag : $(grep ^USER_FLAG .env | cut -d= -f2)   (container: /home/marcus/user.txt)"
echo "Root flag : $(cat .author/root.flag)   (host: /root/root.txt)"
echo "marcus pw : $(grep ^DEV_PASS .env | cut -d= -f2)"
echo "Next: sudo ./verify.sh   then ./reset.sh"
echo "Reminder: restrict port 80 to your IP. The docker socket makes this a host-root box."
