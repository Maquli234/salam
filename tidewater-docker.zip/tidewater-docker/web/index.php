<?php
// Tidewater IT Services - front controller
require __DIR__ . '/includes/config.php';

$page = isset($_GET['page']) ? $_GET['page'] : 'home.php';

// Keep visitors inside the pages directory
$page = str_replace('../', '', $page);

include __DIR__ . '/includes/header.php';
include __DIR__ . '/pages/' . $page;
include __DIR__ . '/includes/footer.php';
