<section class="page narrow">
  <h1>Client portal</h1>
  <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <p class="notice warn">Sign-in failed. Check your username and password, or contact the support desk.</p>
  <?php endif; ?>
  <form method="post" action="/index.php?page=portal.php">
    <label>Username <input name="user" required></label>
    <label>Password <input name="pass" type="password" required></label>
    <button class="btn" type="submit">Sign in</button>
  </form>
</section>
