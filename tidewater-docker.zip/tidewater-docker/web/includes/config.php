<?php
// Application settings - do not commit to public repos
define('SITE_NAME', 'Tidewater IT Services');
define('DB_HOST', 'localhost');
define('DB_NAME', 'tidewater_clients');
define('DB_USER', 'marcus');
define('DB_PASS', '__DB_PASS__');
