<?php
$titles = [
  'home.php' => 'Home', 'services.php' => 'Services', 'about.php' => 'About',
  'team.php' => 'Team', 'contact.php' => 'Contact', 'portal.php' => 'Client portal'
];
$current = isset($_GET['page']) ? $_GET['page'] : 'home.php';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo SITE_NAME; ?></title>
<link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header class="top">
  <a class="brand" href="/index.php?page=home.php">Tidewater<span>IT</span></a>
  <nav>
    <?php foreach ($titles as $file => $label): ?>
      <a href="/index.php?page=<?php echo $file; ?>"<?php echo ($current === $file) ? ' aria-current="page"' : ''; ?>><?php echo $label; ?></a>
    <?php endforeach; ?>
  </nav>
</header>
<main>
